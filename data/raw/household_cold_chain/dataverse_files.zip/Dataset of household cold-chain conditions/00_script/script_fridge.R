# ---------------------------------------------------------------------------------------
#
# Description       : The code provided is designed to generate a series of graphs
#                     using the data in folder N°01_src
#                     
# Authors           : Yvanne PAVIET-SALOMON  <yvanne.paviet-salomon@inrae.fr>
# 
# Creation date     : 2025-11-26 11:37:20 CET
# Modification date : [1] "2025-12-19 08:37:38 CET"" / 178 lines
# 
# Comments          : This script has specific graph generation function.
#
# create_temp_hum_graphic () > Function to create the overall temperature graph

# ---------------------------------------------------------------------------------------

# ----------------------------- path definition-------------

# IMPORTANT: Before running this script, set the working directory to the path where your R script is located.
# Replace ".../Dataset of household cold-chain conditions/00_script" with the correct path on your computer.
# This ensures that all file paths used in the script are relative to this directory.

# Example for Windows:
# setwd("C:/your/path/to/script")

# Example for Mac or Linux:
# setwd("/your/path/to/script")

# Set the working directory
setwd(".../Dataset of household cold-chain conditions/00_script")

# source directory

path_src <- "../01_src"

# result directory
path_res <- "../02_res"

# ----------------------------- package loading

library(stats)      # for statistical functions
library(utils)      # for utility functions (e.g., read.csv, write.csv)
library(graphics)   # for basic graphical functions
library(grDevices)  # for graphical devices
library(datasets)   # for built-in datasets
library(methods)    # for formal methods and classes
library(base)       # for the base R system functions (loaded by default)

# Check if the packages are installed and install them if they are not
required_packages <- c("utils", "graphics", "grDevices", "datasets", "methods")

for (pkg in required_packages) {
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}

# Function to create the overall temperature and relative humidity graph

create_temp_hum_graphic <- function(data, graphic_file_base) {
  
  base_name <- tools::file_path_sans_ext(basename(graphic_file_base))
  
  Time <- data[["Time"]]
  Time <- as.numeric(Time)
 
  temp_cols <- c("T_AMB", "T_MS", "T_TS", "T_VD", "T_DS", "T_FC","TP")
  hum_cols  <- c("RH_AMB", "RH_MS", "RH_TS", "RH_VD", "RH_DS", "RH_FC")
  
  # ------------------------------ Temperature ------------------------------
  y_temp_limits <- range(unlist(data[temp_cols]), na.rm = TRUE)
  temp_colors <- c("red", "orange", "blue", "darkgreen", "purple", "brown", "black")
  
  temp_file <- paste0(graphic_file_base, "_TEMP.png")   
  png(filename = temp_file, width = 1800, height = 1200, res = 300)
  
  par(
    mar = c(5, 4, 4, 6) + 0.1,   # generous margins, especially on the right
    cex.axis = 0.8,            # axis tick label size
    cex.lab  = 0.7,            # axis label size
    cex.main = 0.8,            # title size
    xpd = TRUE                 # allow the legend to be drawn outside the plot region
  )  

  plot(Time, data[[temp_cols[1]]],
       type = "n",
       xlab = "Time (minutes)",
       ylab = "Temperature (°C)",
       ylim = y_temp_limits,
       main = paste("Temperature refrigerator N°", base_name),
       cex.axis = 0.9,
       xaxt="n")
  # Number of days
  jours <- floor(max(Time) / 1440)
  
  # Tick positions = start of each day
  ticks <- 0:jours * 1440
  
  axis(1, at = ticks)

  for (i in seq_along(temp_cols)) {
    lines(Time, data[[temp_cols[i]]], col = temp_colors[i], lwd = 1)
  }
  
  legend("right",
         inset = c(-0.30, 0),  
         legend = temp_cols,
         col = temp_colors,
         lwd = 0.8,
         lty = 1,
         cex = 0.8,
         bty = "n")  
  dev.off()
  Sys.sleep(0.1)
  
  # ------------------------------ Relative humidity ------------------------------
  y_hum_limits <- range(unlist(data[hum_cols]), na.rm = TRUE)
  hum_colors  <- c("red", "orange", "blue", "darkgreen", "purple", "brown")
  
  hum_file <- paste0(graphic_file_base, "_HUM.png")   
  png(filename = hum_file, width = 1800, height = 1200, res = 300)
  
  par(
    mar = c(5, 4, 4, 6) + 0.1,   
    cex.axis = 0.8,         
    cex.lab  = 0.7,         
    cex.main = 0.8,        
    xpd = TRUE              
  )
  

  plot(Time, data[[hum_cols[1]]],
       type = "n",
       xlab = "Time (minutes)",
       ylab = "Relative humidity (%)",
       ylim = y_hum_limits,
       main = paste("Humidity refrigerator N°", base_name),
       cex.axis = 0.8,
       xaxt="n")
  axis(1, at = ticks)  
  for (i in seq_along(hum_cols)) {
    lines(Time, data[[hum_cols[i]]], col = hum_colors[i], lwd = 0.5)
  }
  
  legend("right",
         inset = c(-0.30, 0),  
         legend = hum_cols,
         col = hum_colors,
         lwd = 0.8,
         lty = 1,
         cex = 0.8,
         bty = "n")
  
  
  dev.off()
  Sys.sleep(0.1)
}

#----------------------------- graphic generation

if (length(txt_files) < 1) stop("No .txt files found in the source directory.")

for (i in seq_along(txt_files)) {
  
  fichier <- txt_files[i]
  
  # Base name used to generate *_TEMP.png and *_HUM.png files
  nom_base <- tools::file_path_sans_ext(basename(fichier))
  graphic_base <- file.path(path_res, nom_base)
  
  # Read data
  data <- read.table(fichier, header = TRUE, sep = "\t", stringsAsFactors = FALSE)
  
  # Call the function that generates the two graphs
  create_temp_hum_graphic(data, graphic_base)
}
##------End of code --------