#VERSION FRANÇAISE

Ce fichier README a été généré le [2025-12-18] par [Yvanne Paviet-Salomon].

Dernière mise-à-jour le : [2024-12-19].

##INFORMATIONS GÉNÉRALES
###Titre du jeu de données

Dataset of household cold-chain conditions: temperature and relative humidity monitoring in domestic refrigerators in Bangkok Thailand

###DOI

https://doi.org/10.57745/TMWYBQ

###Adresse de contact

yvanne.paviet-salomon@inrae.fr

##INFORMATIONS MÉTHODOLOGIQUES
###Conditions expérimentales

Ce fichier README fournit les métadonnées associées au jeu de données de température et d’humidité des réfrigérateurs domestiques collectées à Bangkok.
Chaque fichier texte correspond à un réfrigérateur domestique, identifié par un numéro attribué au début de l’étude. Au total, 123 réfrigérateurs domestiques ont été instrumentés, ce qui a conduit à la production de 123 fichiers de données individuels.
Il décrit la signification de chaque colonne, la position des capteurs et les conventions de mesure utilisées dans l’ensemble des fichiers de données brutes.

Le jeu de données comprend trois types de réfrigérateurs (Fig. 1) :

Réfrigérateur à une porte (single-door) : nombres = 41

Réfrigérateur à deux portes avec congélateur en haut (two-door / top-freezer) : nombres = 77

Réfrigérateur à deux portes avec congélateur en bas (two-door / bottom-freezer) : nombres = 5

Le capteur placé dans le réfrigérateur et le gel simulant la viande sont représentés sur la Fig. 2. Le capteur permet de mesurer la température dans le frigo ou à l'extérieur, tandis que le gel, composé d’hydroxyéthyl cellulose, d’eau distillée et d’un agent antifongique, forme une matrice stable reproduisant les conditions thermiques d’un produit alimentaire réel.

Les noms de fichiers suivent la structure :
« NuméroDuRéfrigérateur_TypeDeRéfrigérateur »

###FORMAT DES FICHIERS

Tous les fichiers de données sources sont des fichiers .txt délimités par des tabulations, enregistrés avec un pas de temps de 5 minutes.

Exemple : 001_2DT.txt

Tous les fichiers de traitement sont des fichiers de visualisation .png selon la grandeur physique.

Exemple : 001_2DT_HUM.png

###DESCRIPTION DES COLONNES

Le tableau ci-dessous décrit l’ensemble des colonnes incluses dans les fichiers de données brutes :

Nom de la colonne	Description
Time	Temps écoulé depuis le début de l’enregistrement (minutes)
T_AMB	Température de l’air ambiant à l’extérieur du réfrigérateur
T_MS	Température de l’air sur l’étagère centrale
T_TS	Température de l’air sur l’étagère supérieure
T_VD	Température de l’air dans le bac à légumes
T_DS	Température de l’air sur l’étagère de la porte
T_FC	Température de l’air dans le compartiment congélateur ou la zone la plus froide
RH_AMB	Humidité relative de l’air ambiant à l’extérieur du réfrigérateur
RH_MS	Humidité relative sur l’étagère centrale
RH_TS	Humidité relative sur l’étagère supérieure
RH_VD	Humidité relative dans le bac à légumes
RH_DS	Humidité relative sur l’étagère de la porte
RH_FC	Humidité relative dans le compartiment congélateur
TP	Température du produit

###NOTES SUR LE POSITIONNEMENT DES CAPTEURS

Tous les capteurs ont été positionnés conformément à un protocole d’installation fourni aux participants.

La température dans les réfrigérateurs domestiques a été enregistrée simultanément à des intervalles de 5 minutes pendant 7 jours à l’aide d’enregistreurs TagPlus TH (Freshliance), avec une résolution de 0,1 °C sur une plage de mesure allant de −30 °C à +70 °C. Les mesures présentent une incertitude élargie de ±0,5 °C (k = 2).

L’humidité relative a été enregistrée dans les réfrigérateurs domestiques à des intervalles de 5 minutes à l’aide d’enregistreurs TagPlus TH (Freshliance), avec une résolution de 0,1 % et une incertitude élargie de ±3 % (k = 2).
Cinq jours de mesures ont été sélectionnés après prise en compte du temps de stabilisation.
Le type de réfrigérateur a été déclaré par les participants et directement encodé dans le nom du fichier.

---

#ENGLISH VERSION

This README file was generated on [2025-12-18] by [Yvanne Paviet-Salomon].

Last update: [2024-12-18].

##GENERAL INFORMATION
###Dataset title

Dataset of household cold-chain conditions: temperature and relative humidity monitoring in domestic refrigerators in Bangkok Thailand

###DOI

https://doi.org/10.57745/TMWYBQ

###Contact address

yvanne.paviet-salomon@inrae.fr

##METHODOLOGICAL INFORMATION
###Experimental conditions

This README file provides the metadata associated with the domestic refrigerator temperature and relative humidity dataset collected in Bangkok.
Each text file corresponds to one domestic refrigerator, identified by a number assigned at the beginning of the study. In total, 123 domestic refrigerators were instrumented, resulting in the production of 123 individual data files.
It describes the meaning of each column, the sensor positions, and the measurement conventions used across all raw data files.

The dataset includes three types of refrigerators (Fig. 1):

Single-door refrigerator: numbers = 41

Two-door refrigerator with top freezer (two-door / top-freezer): numbers = 77

Two-door refrigerator with bottom freezer (two-door / bottom-freezer): numbers = 5

The sensor placed in the refrigerator and the meat-simulating gel are shown in Fig. 2. 
The sensor allows measurement of the temperature inside the fridge or externally, while the gel, composed of hydroxyethyl cellulose, distilled water, and an antifungal agent, forms a stable matrix reproducing the thermal conditions of a real food product.

File names follow the structure:
“RefrigeratorNumber_RefrigeratorType”

##FILE FORMAT

All source data files are tab-delimited .txt files recorded at a 5-minute time interval.

Example: 001_2DT.txt

All processed files are .png visualization files, generated according to the physical variable.

Example: 001_2DT_HUM.png

##COLUMN DESCRIPTION

The table below describes all columns included in the raw data files:

Column name	Description
Time	Time elapsed since the start of the recording (minutes)
T_AMB	Ambient air temperature outside the refrigerator
T_MS	Air temperature at the middle shelf
T_TS	Air temperature at the top shelf
T_VD	Air temperature in the vegetable drawer
T_DS	Air temperature at the door shelf
T_FC	Air temperature in the freezer compartment or coldest zone
RH_AMB	Relative humidity of ambient air outside the refrigerator
RH_MS	Relative humidity at the middle shelf
RH_TS	Relative humidity at the top shelf
RH_VD	Relative humidity in the vegetable drawer
RH_DS	Relative humidity at the door shelf
RH_FC	Relative humidity in the freezer compartment
TP	Product temperature

##SENSOR DEPLOYMENT NOTES

All sensors were positioned according to installation protocol provided to participants.

Temperature in domestic refrigerators were recorded simultaneously at 5-minute intervals over 7 days using TagPlus TH loggers (Freshliance), with a resolution of 0.1 °C over a measurement range of −30 °C to +70 °C. The measurements have an expanded uncertainty of ±0.5 °C (k = 2).
Relative humidity was recorded in domestic refrigerators at 5-minute intervals using TagPlus TH loggers (Freshliance), with a resolution of 0.1 % and an expanded uncertainty of ±3 % (k = 2). 
Five days of measurements were selected after accounting for the stabilization time.
Refrigerator type was reported by participants and directly encoded in the file name.